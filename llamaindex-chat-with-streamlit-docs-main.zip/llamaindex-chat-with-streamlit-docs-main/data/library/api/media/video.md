---
title: st.video
slug: /library/api-reference/media/st.video
description: st.video displays a video player.
---

<Autofunction function="streamlit.video" />
