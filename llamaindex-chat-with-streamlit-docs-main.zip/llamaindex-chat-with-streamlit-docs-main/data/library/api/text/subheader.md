---
title: st.subheader
slug: /library/api-reference/text/st.subheader
description: st.subheader displays text in subheader formatting.
---

<Autofunction function="streamlit.subheader" />

<Image src="/images/api/st.subheader.png" clean />
