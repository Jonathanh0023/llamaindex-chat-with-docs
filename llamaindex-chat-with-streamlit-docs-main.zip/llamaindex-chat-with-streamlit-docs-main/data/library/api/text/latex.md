---
title: st.latex
slug: /library/api-reference/text/st.latex
description: st.latex displays mathematical expressions formatted as LaTeX.
---

<Autofunction function="streamlit.latex" />

<Image src="/images/api/st.latex.png" clean />
