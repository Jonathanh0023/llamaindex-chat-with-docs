---
title: st.text
slug: /library/api-reference/text/st.text
description: st.text writes fixed-width and preformatted text.
---

<Autofunction function="streamlit.text" />

<Image src="/images/api/st.text.png" clean />
