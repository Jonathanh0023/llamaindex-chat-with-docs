---
title: st.markdown
slug: /library/api-reference/text/st.markdown
description: st.markdown displays string formatted as Markdown.
---

<Autofunction function="streamlit.markdown" />

<Image src="/images/api/st.markdown.png" clean />
