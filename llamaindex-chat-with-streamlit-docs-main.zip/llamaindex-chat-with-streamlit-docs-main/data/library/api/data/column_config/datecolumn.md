---
title: st.column_config.DateColumn
slug: /library/api-reference/data/st.column_config/st.column_config.datecolumn
---

<Autofunction function="streamlit.column_config.DateColumn" />
