---
title: st.column_config.Column
slug: /library/api-reference/data/st.column_config/st.column_config.column
---

<Autofunction function="streamlit.column_config.Column" />
