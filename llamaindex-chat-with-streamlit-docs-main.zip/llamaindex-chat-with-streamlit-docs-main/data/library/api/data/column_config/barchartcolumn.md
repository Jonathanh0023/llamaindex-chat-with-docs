---
title: st.column_config.BarChartColumn
slug: /library/api-reference/data/st.column_config/st.column_config.barchartcolumn
---

<Autofunction function="streamlit.column_config.BarChartColumn" />
