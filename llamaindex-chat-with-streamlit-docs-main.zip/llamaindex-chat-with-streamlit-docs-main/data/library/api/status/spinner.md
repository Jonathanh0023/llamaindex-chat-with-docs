---
title: st.spinner
slug: /library/api-reference/status/st.spinner
description: st.spinner temporarily displays a message while executing a block of code.
---

<Autofunction function="streamlit.spinner" />
