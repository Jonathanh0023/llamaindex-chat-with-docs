---
title: st.balloons
slug: /library/api-reference/status/st.balloons
description: st.balloons displays celebratory balloons!
---

<Autofunction function="streamlit.balloons" />
