---
title: st.stop
slug: /library/api-reference/control-flow/st.stop
description: st.stop stops the execution immediately.
---

<Autofunction function="streamlit.stop" />
