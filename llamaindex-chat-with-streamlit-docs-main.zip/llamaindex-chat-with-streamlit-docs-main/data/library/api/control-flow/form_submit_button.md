---
title: st.form_submit_button
slug: /library/api-reference/control-flow/st.form_submit_button
description: st.form_submit_button displays a form submit button.
---

<Autofunction function="streamlit.form_submit_button" />
