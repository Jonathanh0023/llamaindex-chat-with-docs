---
title: st.line_chart
slug: /library/api-reference/charts/st.line_chart
description: st.line_chart displays a line chart.
---

<Autofunction function="streamlit.line_chart" />
