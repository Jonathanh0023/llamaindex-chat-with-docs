---
title: st.area_chart
slug: /library/api-reference/charts/st.area_chart
description: st.area_chart displays an area chart.
---

<Autofunction function="streamlit.area_chart" />
